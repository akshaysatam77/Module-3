package com.cg.appl.daos;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.appl.JdbcUtil;
import com.cg.appl.entities.Employee;


import com.cg.appl.exceptions.EmpException;

public class EmpDaoImpl implements EmpDao {
	private JdbcUtil util;

	public EmpDaoImpl() {
		
	util = new JdbcUtil();
		
		
	}

	
	
	@Override
	public Employee getEmpDetails(int empNo) throws EmpException {
	
		Connection connect=null;
		PreparedStatement stmt= null;
		ResultSet rs = null;
		String qry = "SELECT EMPNO, ENAME,SAL FROM EMP WHERE EMPNO=?";
		
		try {
			connect = util.getConnection();
		    stmt = connect.prepareStatement(qry);
		    stmt.setInt(1, empNo);
		    
		    
		     rs = stmt.executeQuery();
		     
		    if(rs.next()){
		  
		    	
		    	String empNm = rs.getString("ENAME");
		    	float empSal = rs.getFloat("SAL");
		    	
		    	Employee emp = new Employee(empNo, empNm, empSal);
		    	
		    	return emp;
		    	
		    }else
		    {
		    	throw new EmpException("Employee id is wrong");
		    }
		    
			
			
		} catch (SQLException e) {
			
			throw new EmpException("JDBC failed", e);
		}finally{
			try {
				if(rs != null){
					rs.close();
				}
				if(stmt != null){
				   stmt.close();
				}
				if(connect != null){
				   connect.close();
				}
			} catch (SQLException e)
			
			{
				
				throw new EmpException("JDBC connection closing failed");
			}
		}
		
		
	
	}

}
