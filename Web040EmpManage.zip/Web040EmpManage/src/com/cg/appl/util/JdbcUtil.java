package com.cg.appl.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import oracle.jdbc.pool.OracleDataSource;

public class JdbcUtil {
		
		private OracleDataSource dataSource;
		
		public JdbcUtil() {
			
				
				
					try {
						
				dataSource= new OracleDataSource();
				dataSource.setURL("jdbc:oracle:thin:@10.125.6.62:1521:ORCL11G");
				dataSource.setUser("labg104trg11");
				dataSource.setPassword("labg104oracle");
				dataSource.setDriverType("oracle");
			
				
			
		}catch(SQLException e){
				e.printStackTrace();
				
			}
			
	
			
		
		}
		public Connection getConnection() throws SQLException{
			return dataSource.getConnection();
		}
		@Override
		protected void finalize() throws Throwable {
			dataSource.close();
			super.finalize();
		}
		
		
		
}
