package com.cg.appl.tests;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.cg.appl.entities.Employee;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.services.EmpServices;
import com.cg.appl.services.EmpServicesImpl;

public class TestEmpServices {
	
	private static EmpServices services;

	@Before
	public void setUp() throws Exception {
		
		services = new EmpServicesImpl();
		
	}

	@After
	public void tearDown() throws Exception {
		
		services = null;
		
	}

	@Test
	public void testGetEmpDetails() {
		
		Employee expectedEmp = new Employee(7499, "ALLEN", 1600);
		Employee actualEmp;
		try {
			actualEmp = services.getEmpDetails(7499);
			Assert.assertEquals(expectedEmp, actualEmp);
		} catch (EmpException e) {
			
			e.printStackTrace();
		}
		
	}
	@Test(expected=EmpException.class)
	public void testGetExceptionOnWrongEmpNo() throws EmpException{
		
		Employee actualEmp = services.getEmpDetails(7499);
		
	}
	
	
}	
	