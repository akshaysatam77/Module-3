package com.cg.appl.dao;



import java.util.List;

import com.cg.appl.UserException.UserException;
import com.cg.appl.entities.BillDetails;
import com.cg.appl.entities.Consumers;

public interface UserMasterDao {
	com.cg.appl.entities.User getUserDetails(String userName) throws UserException;
    boolean consumer(BillDetails b,double lastreading) throws UserException;
    List<com.cg.appl.entities.Consumers> getConsumers() throws UserException;
    List<BillDetails> getBillDetails(int consumer_num) throws UserException;
    Consumers getConsumers(int consumer_num) throws UserException;
}
