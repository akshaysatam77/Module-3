package com.cg.appl.Services;

import com.cg.appl.UserException.UserException;

public interface UserMasterServices {
	com.cg.appl.entities.User getUserDetails(String userName)
			throws UserException;

	boolean isUserAuthenticated(String username, String Password)
			throws UserException;
}
