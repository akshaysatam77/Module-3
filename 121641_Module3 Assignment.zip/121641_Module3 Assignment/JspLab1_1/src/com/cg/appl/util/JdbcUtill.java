package com.cg.appl.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import oracle.jdbc.pool.OracleDataSource;

import org.apache.log4j.Logger;

//import com.cg.mobileshop.exception.MobileExceptions;

public class JdbcUtill {

//	private static final Logger mylogger = Logger.getLogger(JdbcUtill.class);
//	private Properties p;
	private OracleDataSource dataSource ;

	public JdbcUtill() {
	//	p = new Properties();
		//FileInputStream fileInputStream = null;
		try {
			/*fileInputStream = new FileInputStream("d://Users//nikpande//Nikhil//Workspace//Web020LoginSimple//myprop.properties");
			p.load(fileInputStream);
			dataSource = new OracleDataSource();
			dataSource.setURL(p.getProperty("oracle.url"));
			dataSource.setUser(p.getProperty("oracle.uname"));
			dataSource.setPassword(p.getProperty("oracle.upass"));
			dataSource.setDriverType("oracle");
			// System.out.println(p.getProperty("oracle.uname"));
		
			*/
			dataSource = new OracleDataSource();
			dataSource.setURL("jdbc:oracle:thin:@10.125.6.62:1521:ORCL11G");
			dataSource.setUser("labg104trg38");
			dataSource.setPassword("labg104oracle");
			dataSource.setDriverType("oracle");
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}

	public Connection getConnection() throws SQLException{

		return dataSource.getConnection();

	}

	@Override
	protected void finalize() throws Throwable {
		dataSource.close();
		super.finalize();
	}
}
