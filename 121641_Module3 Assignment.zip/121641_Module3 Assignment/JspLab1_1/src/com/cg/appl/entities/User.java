package com.cg.appl.entities;

import java.io.Serializable;



public class User implements Serializable {

/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
private	String userName;
private String password;
private String userFullname;
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getUserFullname() {
	return userFullname;
}
public void setUserFullname(String userFullname) {
	this.userFullname = userFullname;
}
public User(String userName, String password, String userFullname) {
	super();
	this.userName = userName;
	this.password = password;
	this.userFullname = userFullname;
}


}
