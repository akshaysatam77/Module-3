package com.cg.appl.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.omg.CORBA.PRIVATE_MEMBER;

import com.cg.appl.entities.Employee;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.services.EmpServicesImpl;

@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private EmpServicesImpl service;
	private RequestDispatcher requestDispatcher;
	private String nextJspString;
	int empno = 4010;

	public void init() throws ServletException {
		service = new EmpServicesImpl();
	}

	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String command = request.getServletPath();
		System.out.println(command);

		switch (command) {
		case "/register.do":

			try {

				String name = request.getParameter("name");
				String lastname = request.getParameter("lastname");
				String password = request.getParameter("password");
				String gender = request.getParameter("gender");
				String[] skillset = request.getParameterValues("skill");
				String skill="";
			    for(String str: skillset)
			    	skill=skill+str+" ";
				
				String city = request.getParameter("city");

				Employee employee = new Employee(name, lastname, password,
						gender, skill, city);
				if(service.addEmp(employee))
				{request.setAttribute("emp", employee);
				nextJspString = "/menu.jsp";
					
				}
				else {
					request.setAttribute("errorMsg", "SOME ERROR");
					nextJspString = "/errors.jsp";
				}
				
			} catch (NumberFormatException e) {
				request.setAttribute("errorMsg", "WRONG NUMBER");
				nextJspString = "/errors.jsp";
			} catch (EmpException e) {

				request.setAttribute("errorMsg", "Regestration failled !!!");
				nextJspString = "/errors.jsp";
				// TODO Auto-generated catch block
				// e.printStackTrace();
			}

			break;

		}
		requestDispatcher = request.getRequestDispatcher(nextJspString);
		requestDispatcher.forward(request, response);

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	public void destroy() {
		service = null;
	}

}
