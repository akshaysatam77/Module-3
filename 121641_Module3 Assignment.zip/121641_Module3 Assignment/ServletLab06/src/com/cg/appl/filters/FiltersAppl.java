package com.cg.appl.filters;

import java.io.IOException;

import javax.servlet.DispatcherType;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.jstl.core.Config;

/**
 * Servlet Filter implementation class FiltersAppl
 */
@WebFilter(dispatcherTypes = { DispatcherType.REQUEST }, urlPatterns = { "/index.jsp" })
public class FiltersAppl implements Filter {
	//protected FilterConfig config = null;
//	ServletConfig config=null;
	ServletContext context=null;

	
	
	public FiltersAppl() {
		// TODO Auto-generated constructor stub
	}

	public void destroy() {
		// TODO Auto-generated method stub
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		System.out.println("IN  DO FILTER FILTER");
		long before = System.currentTimeMillis();
		
		long after = System.currentTimeMillis();
		String name = "";
		if (request instanceof HttpServletRequest) {
			name = ((HttpServletRequest) request).getRequestURI();
		}
//	config.getServletContext().log(name + ":" + (after - before) + "ms");
		this.context.log(name + ":" + (after - before) + "ms");
		System.out.println("LEAVING DO FILTER");
		chain.doFilter(request, response);
		this.context.log(name + ":" + (after - before) + "ms");
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
	this.context= fConfig.getServletContext();
	this.context.log("INIT OF FILTER");
	}

}
