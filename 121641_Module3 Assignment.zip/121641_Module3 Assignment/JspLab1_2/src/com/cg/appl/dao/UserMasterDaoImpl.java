package com.cg.appl.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.appl.UserException.UserException;
import com.cg.appl.entities.BillDetails;
import com.cg.appl.entities.User;
import com.cg.appl.util.*;

public class UserMasterDaoImpl implements UserMasterDao {
	private JndiUtil jdbcUtill = null;

	public UserMasterDaoImpl() throws UserException {
		// jdbcUtill=new JdbcUtill();
		jdbcUtill = new JndiUtil();
	}

	@Override
	public User getUserDetails(String userName) throws UserException {
		PreparedStatement stat = null;
		Connection connection = null;
		ResultSet rs = null;

		String Query = "select username,password,userfname from usermaster where username=? ";
		try {

			connection = jdbcUtill.getConnection();
			stat = connection.prepareStatement(Query);
			stat.setString(1, userName);
			rs = stat.executeQuery();
			if (rs.next()) {
				String Password = rs.getString("password");
				String userfname = rs.getString("userfname");
				User usrUser = new User(userName, Password, userfname);
				return usrUser;
			} else {
				throw new UserException("Wrong user Name");
			}

		} catch (SQLException e) {
			throw new UserException("JDBC FAILED");
		} finally {
			if (rs != null) {
				try {
					rs.close();
					if (stat != null) {
						stat.close();
					}
					if (connection != null) {
						connection.close();
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					// e.printStackTrace();
					throw new UserException("Connection Closing failed");
				}
			}

		}
	}

	@Override
	public boolean consumer(BillDetails b, double lastmonth)
			throws UserException {

		PreparedStatement stat = null;
		Connection connection = null;
		ResultSet rs = null;

		String Query = "insert into BillDetails values(seq_bill_num.nextval,?,?,?,?,sysdate) ";
		try {
			double amount = UserMasterDaoImpl.UnitConsumed(lastmonth,
					b.getCur_reading());
			if(amount==0.0)
			{
				return false;
			}
			else{
			b.setNetAmount(amount);
			b.setUnitConsumed(b.getCur_reading()-lastmonth);

			connection = jdbcUtill.getConnection();
			stat = connection.prepareStatement(Query);
			stat.setInt(1, b.getConsumer_num());
			stat.setInt(2,(int) b.getCur_reading());
			stat.setInt(3,(int) b.getUnitConsumed());
			stat.setInt(4,(int) b.getNetAmount());
			rs = stat.executeQuery();
			if (rs.next()) {
				
				return true;
			} else {
				
				return false;
			}
			}
		} catch (SQLException e) {
		//	throw new UserException("JDBC FAILED");
			throw new UserException("USER NOT FOUND");		}

	}

	public static double UnitConsumed(double lastmonth, double currentmonth) throws UserException {
		double totalcon = currentmonth - lastmonth;
		if(totalcon<0)
		{
			throw new UserException("CURRENT MONTH READING CAN NOT BE LESS THAN PREVIOUS MONTH READING");
		}
		double netamount = totalcon * 1.15 + 100;
		return netamount;

	}

}
