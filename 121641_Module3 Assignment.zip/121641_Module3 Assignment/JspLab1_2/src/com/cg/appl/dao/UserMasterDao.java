package com.cg.appl.dao;



import com.cg.appl.UserException.UserException;
import com.cg.appl.entities.BillDetails;

public interface UserMasterDao {
	com.cg.appl.entities.User getUserDetails(String userName) throws UserException;
    boolean consumer(BillDetails b,double lastreading) throws UserException;
}
