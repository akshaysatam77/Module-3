package com.cg.appl.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.appl.Services.UserMasterServices;
import com.cg.appl.Services.UserMasterServicesImpl;
import com.cg.appl.UserException.UserException;
import com.cg.appl.entities.BillDetails;
import com.cg.appl.entities.User;

@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserMasterServices service;
	private RequestDispatcher requestDispatcher;
	private String nextJspString;
	String msg = null;
	private ServletContext ctxContext;

	public void init() throws ServletException {
		ctxContext = super.getServletContext();
	service=(UserMasterServices) ctxContext.getAttribute("services");
	}

	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String command = request.getServletPath();
		System.out.println(command);

		switch (command) {
		case "/login.do": {
			nextJspString = "/login.jsp";
		}
			break;
		case "/authenticate.do": {
			String uString = request.getParameter("userName");
			String password = request.getParameter("password");

			try {

				boolean isAuthenticated = service.isUserAuthenticated(uString,
						password);

				if (isAuthenticated) {
					ctxContext.log("AUTHENTICATE"+uString);
					// ///////////////////////////////////////////////////
					// starting session
					User user = service.getUserDetails(uString);
					HttpSession session = request.getSession(true);
					System.out.println(session.getId());
					session.setAttribute("users", user.getUserName());

					// ///////////////////////////////////////////////////
					nextJspString = "/mainMenu.jsp";
				} else {
					System.out.println("NO");
					/*
					 * dispatcher = request.getRequestDispatcher("/login.jsp");
					 * dispatcher.forward(request, resp);
					 */
					msg = "Wrong Credential...Enter Again";
					request.setAttribute("errorMsg", msg);
					nextJspString = "/login.jsp";
				}

			} catch (UserException e) {
				/*
				 * dispatcher = request.getRequestDispatcher("/error.jsp");
				 * dispatcher.forward(request, resp);
				 */
				msg = "User Name doest not exist";
				request.setAttribute("errorMsg", msg);
				nextJspString = "/error.jsp";
				//ctxContext.log(e, msg);
				ctxContext.log(e.getMessage());
				// TODO Auto-generated catch block
				// e.printStackTrace();
			}
		}
			break;

		case "/logout.do": {
			try{
			HttpSession session = request.getSession(false);
			session.invalidate();// destroys session
			}
			catch(Exception e){}
			nextJspString = "/login.jsp";

		}
			break;
			
			
		case "/cal.do":{
			HttpSession session = request.getSession(false);
			try{
			String users=(String) session.getAttribute("users");
			System.out.println("xxxxxx"+users);

			String consumer_num1 = request.getParameter("number");
			String cur_reading1 = request.getParameter("current");
			String lastreading1=request.getParameter("last");
			
			int consumer_num=Integer.parseInt(consumer_num1);
			double cur_reading=Double.parseDouble(cur_reading1);
			double lastreading=Double.parseDouble(lastreading1);
			
			BillDetails b=new BillDetails(consumer_num, cur_reading);
			try {
			if(service.consumer(b, lastreading))
			{	request.setAttribute("consumer", b);
			nextJspString = "/data.jsp";
				
			}
			else{

				
				msg = "CURRENT MONTH READING CAN NOT BE LESS THAN PREVIOUS MONTH READING";
				request.setAttribute("errorMsg", msg);
				nextJspString = "/error.jsp";
				//ctxContext.log(e, msg);
				
			}
			} catch (UserException e) {
			
				msg = "Consumers NOT FOUND";
				request.setAttribute("errorMsg", msg);
				nextJspString = "/error.jsp";
				//ctxContext.log(e, msg);
				ctxContext.log(e.getMessage());
			}
		
	
			
			}
			catch(Exception e)
			{
				msg = "NOT LOGIN..PLEASE LOGIN";
				request.setAttribute("errorMsg", msg);
				nextJspString = "/error.jsp";
				//ctxContext.log(e, msg);
				//e.printStackTrace();
			ctxContext.log(e.getMessage());
			}	} break;
		}
		requestDispatcher = request.getRequestDispatcher(nextJspString);
		requestDispatcher.forward(request, response);

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	public void destroy() {
		service = null;
	}

}
