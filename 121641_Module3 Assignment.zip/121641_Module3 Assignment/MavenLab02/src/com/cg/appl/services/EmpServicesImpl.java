package com.cg.appl.services;

import com.cg.appl.daos.EmpDaoImpl;
import com.cg.appl.entities.Employee;
import com.cg.appl.exceptions.EmpException;

public class EmpServicesImpl implements EmpService {
	EmpDaoImpl dao;

	public EmpServicesImpl() {
		dao = new EmpDaoImpl();
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean addEmp(Employee e) throws EmpException {
		// TODO Auto-generated method stub
		return dao.addEmp(e);
	}

}
