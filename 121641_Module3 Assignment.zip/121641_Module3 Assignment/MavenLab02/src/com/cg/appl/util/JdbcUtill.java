package com.cg.appl.util;


import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.pool.OracleDataSource;

import org.apache.log4j.Logger;

public class JdbcUtill {
	private OracleDataSource dataSource;

	public JdbcUtill() {
		try {
			dataSource = new OracleDataSource();
			dataSource.setURL("jdbc:oracle:thin:@10.125.6.62:1521:ORCL11G");
			dataSource.setUser("labg104trg38");
			dataSource.setPassword("labg104oracle");
			dataSource.setDriverType("oracle");

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public Connection getConnection() throws SQLException {

		return dataSource.getConnection();

	}

	@Override
	protected void finalize() throws Throwable {
		dataSource.close();
		super.finalize();
	}
}
