package com.cg.appl.tests;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.appl.entities.Employee;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.services.EmpService;
import com.cg.appl.services.EmpServicesImpl;

public class TestEmpServices {
private static EmpService emp;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		emp=new EmpServicesImpl();
	}

	@Test
	public void testGetEmpDetails() {
	try {
		Employee employee =new Employee(7369, "SMITH", 800);
		Assert.assertEquals(employee, emp.getEmpDetails(7369));
		
	} catch (EmpException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	
	@Test(expected=EmpException.class)
	void TestGetExceptionByWrongId() throws EmpException
	{
		Employee actualEmp=emp.getEmpDetails(7888);
		
	}

}
