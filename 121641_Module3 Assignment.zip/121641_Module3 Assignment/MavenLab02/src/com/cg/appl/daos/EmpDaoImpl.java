package com.cg.appl.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.cg.appl.entities.Employee;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.util.JdbcUtill;

public class EmpDaoImpl implements EmpDao {
	private JdbcUtill jdbcUtill;

	public EmpDaoImpl() {
		jdbcUtill = new JdbcUtill();
	}


	
	@Override
	public boolean addEmp(Employee e) throws EmpException {

		PreparedStatement stat = null;
		Connection connection = null;
		ResultSet rs = null;

		System.out.println("HERE iN INSERT ADD");
		String Query = "insert into RegisteredUsers values(?,?,?,?,?,?) ";
		try {
			connection = jdbcUtill.getConnection();
			stat = connection.prepareStatement(Query);
			stat.setString(1, e.getFirstname());
			stat.setString(2, e.getLastname());
			stat.setString(3, e.getPassword());
			stat.setString(4, e.getGender());
			stat.setString(5, e.getSkillset());
			stat.setString(6, e.getCity());
			rs = stat.executeQuery();
			if (rs.next()) {
				System.out.println("HERE iN INSERT NEXT");
				return true;
			

			} else {

				throw new EmpException("UNABLE TO INSERT>> USER REGESTRATION FAILED");

			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return false;
	}

}
