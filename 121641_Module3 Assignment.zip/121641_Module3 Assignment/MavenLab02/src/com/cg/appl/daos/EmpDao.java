package com.cg.appl.daos;

import com.cg.appl.entities.Employee;
import com.cg.appl.exceptions.EmpException;

public interface EmpDao {
	
	boolean addEmp(Employee e)throws EmpException;

}
