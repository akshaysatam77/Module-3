package com.cg.magicworld.dao;

import java.util.List;

import com.cg.magicworld.dto.Show;
import com.cg.magicworld.exception.ShowException;


public interface IShowDao {
public List<Show> showAll() throws ShowException;
public int updateSeats(int seats, String showName) throws ShowException;
}
