package com.cg.magicworld.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.magicworld.util.JndiUtil;
import com.cg.magicworld.dto.Show;
import com.cg.magicworld.exception.ShowException;

public class ShowDaoImpl implements IShowDao {
	private JndiUtil util;
	
	public ShowDaoImpl() throws ShowException {
		util=new JndiUtil();
	}

	@Override
	public List<Show> showAll() throws ShowException {
		Connection conn = null;
		PreparedStatement pstm = null;
		String query="SELECT SHOWID,SHOWNAME,LOCATION,SHOWDATE,AVSEATS,PRICETICKET FROM SHOWDETAILS";
		List<Show> myShow=new ArrayList<Show>();
		try {
			conn=util.getConnection();
			pstm=conn.prepareStatement(query);
			ResultSet rs=pstm.executeQuery();
			while(rs.next())
			{
				Show e=new Show();
			    e.setAvSeats(rs.getInt("AVSEATS"));
			    e.setLocation(rs.getString("LOCATION"));
			    e.setPrice(rs.getDouble("PRICETICKET"));
			    e.setShowDate(rs.getDate("SHOWDATE"));
                e.setShowId(rs.getString("SHOWID"));
                e.setShowName(rs.getString("SHOWNAME"));
			    myShow.add(e);
			}
		} catch (SQLException e) {
			
		throw new ShowException("Problem in retrieving data",e);
		}finally{
			
			try {
				if(conn!=null)
				{
					conn.close();
				}
				if(pstm!=null)
				{
					pstm.close();
				}
				
			} catch (SQLException e) {
			throw new ShowException("Connection was not established",e);
			}
			
		}
		return myShow;
	}

	@Override
	public int updateSeats(int seats,String showName) throws ShowException {
		Connection conn = null;
		PreparedStatement pstm = null;
		int value=0;
		String query="UPDATE SHOWDETAILS SET AVSEATS=AVSEATS-? WHERE SHOWNAME=?";
		try {
			conn=util.getConnection();
			pstm=conn.prepareStatement(query);
			pstm.setInt(1,seats);
			pstm.setString(2,showName);
			value=pstm.executeUpdate();
		
		} catch (SQLException e) {
			
		throw new ShowException("Problem in  data",e);
		}finally{
			
			try {
				if(conn!=null)
				{
					conn.close();
				}
				if(pstm!=null)
				{
					pstm.close();
				}
				
			} catch (SQLException e) {
			throw new ShowException("Connection was not established",e);
			}
			
		}
	
		return value;
	}



	

}
