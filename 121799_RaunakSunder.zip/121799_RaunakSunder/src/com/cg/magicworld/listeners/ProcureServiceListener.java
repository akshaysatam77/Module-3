package com.cg.magicworld.listeners;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.cg.magicworld.exception.ShowException;
import com.cg.magicworld.services.IShowService;
import com.cg.magicworld.services.ShowServiceImpl;


@WebListener
public class ProcureServiceListener implements ServletContextListener {
	private IShowService services;
	ServletContext ctx=null;
    public void contextInitialized(ServletContextEvent event)  { 
    	try {
			ctx=event.getServletContext();
			services=new ShowServiceImpl();
			ctx.setAttribute("services", services);
		} catch (ShowException e) {
			ctx.log(e.getMessage());
		}
    }
    
    public void contextDestroyed(ServletContextEvent arg0)  { 
        
    }

}
