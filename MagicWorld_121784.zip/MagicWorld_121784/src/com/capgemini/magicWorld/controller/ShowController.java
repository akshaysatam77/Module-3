package com.capgemini.magicWorld.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.magicWorld.dto.BookTicket;
import com.capgemini.magicWorld.exception.BookException;
import com.capgemini.magicWorld.service.ShowService;
import com.capgemini.magicWorld.service.ShowServiceImpl;

@WebServlet("*.do")
public class ShowController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ShowService service;
	private RequestDispatcher dispatcher;

	public void init(ServletConfig config) throws ServletException {
		service=new ShowServiceImpl();
	}
	
	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, BookException{
		String path=request.getServletPath();
		if(path.equals("/*.do")){
			List<BookTicket> myList=new ArrayList<>();
			
				myList=service.showDetails();
			
				//HttpSession session=request.getSession(true);
				request.setAttribute("data",myList);
				dispatcher=request.getRequestDispatcher("ShowDetails.jsp");
				dispatcher.forward(request, response);
			
			
			
		}
		
		else
			if(path.equals("/bookForm.do")){
				BookTicket bt= new BookTicket();
				bt.setShowName(request.getParameter("showName"));
				bt.setPrice(Float.parseFloat(request.getParameter("price")));
				bt.setAvailableSeats(Integer.parseInt(request.getParameter("availableSeats")));
				
				request.setAttribute("data",bt);
				dispatcher=request.getRequestDispatcher("BookingForm.jsp");
				dispatcher.forward(request, response);
				
			}
			else
				if(path.equals("/bookNow.do")){
				
					String showName=request.getParameter("showName");
					String priceStr=request.getParameter("price");
					String custName=request.getParameter("custName");
					String mobile=request.getParameter("mobile");
					int availableSeats=Integer.parseInt(request.getParameter("availableSeats"));
				    int seats=Integer.parseInt(request.getParameter("seats"));
					System.out.println(seats);
					int value=0;
					availableSeats=availableSeats-seats;
					value=service.updateSeats(showName,availableSeats);
						if(value>0){
							System.out.println("kuygiy");
						BookTicket bt=new BookTicket();
						bt.setShowName(showName);
						bt.setPrice(Float.parseFloat(priceStr));
						bt.setCustName(custName);
						bt.setMobile(mobile);
						bt.setSeats(seats);
						request.setAttribute("book",bt);
						
						dispatcher=request.getRequestDispatcher("Success.jsp");
						dispatcher.forward(request, response);
						}
					
			
				}
				else
					if(path.equals("/home.do")){
						HttpSession session=request.getSession(false);
						session.invalidate();
						dispatcher=request.getRequestDispatcher("index.jsp");
						dispatcher.forward(request, response);
					}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request,response);
		} catch (BookException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request,response);
		} catch (BookException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
