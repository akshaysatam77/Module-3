package com.capgemini.magicWorld.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.capgemini.magicWorld.exception.BookException;

//import oracle.jdbc.pool.OracleDataSource;

public class DbUtil {
	
	
	//private OracleDataSource dataSource;
	   
	public DbUtil() throws BookException{
			
		}
		
		/*public Connection getConnection() throws BookException{
			try {
				dataSource=new OracleDataSource();
				dataSource.setURL("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G");
				dataSource.setUser("labg104trg12");
				dataSource.setPassword("labg104oracle");
				dataSource.setDriverType("oracle");
				return dataSource.getConnection();
			}catch (SQLException e) {
				//e.printStackTrace();
				throw new BookException("Failed to connect"+e);
			}
			
		}*/
	
	public Connection obtainConnection() throws BookException{
		Connection conn=null;
		InitialContext context;
	    try {
	    	context=new InitialContext();
			DataSource source=(DataSource)context.lookup("java:/NewOracleDS");
			conn=source.getConnection();
		} catch (NamingException |SQLException e) {
			e.printStackTrace();
			throw new BookException("Problem in connection");
		}
	    
		return conn;
	}

		/*@Override
		protected void finalize() throws Throwable {
			dataSource.close();
			super.finalize();
		}*/

}
