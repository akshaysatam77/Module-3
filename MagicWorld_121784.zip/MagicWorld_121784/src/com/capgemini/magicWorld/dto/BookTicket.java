package com.capgemini.magicWorld.dto;

import java.io.Serializable;

public class BookTicket implements Serializable{
        
		private String showId;
	    private String showName;
		private String location;
		private String date;
		private float price;
		private int availableSeats;
		private String bookStatus;
		
		private String custName;
		private String mobile;
		private int seats;
		public BookTicket() {
			super();
		}
		public BookTicket(String showId,String showName, String location, String date,
				float price, int availableSeats,String bookStatus,String custName,String mobile,int seats) {
			super();
			this.showId=showId;
			this.showName = showName;
			this.location = location;
			this.date = date;
			this.price = price;
			this.availableSeats = availableSeats;
			this.bookStatus=bookStatus;
			
			this.custName=custName;
			this.mobile=mobile;
			this.seats=seats;
		}
		
		public String getShowId() {
			return showId;
		}
		public void setShowId(String showId) {
			this.showId = showId;
		}
		public String getCustName() {
			return custName;
		}
		public void setCustName(String custName) {
			this.custName = custName;
		}
		public String getMobile() {
			return mobile;
		}
		public void setMobile(String mobile) {
			this.mobile = mobile;
		}
		public int getSeats() {
			return seats;
		}
		public void setSeats(int seats) {
			this.seats = seats;
		}
		public String getBookStatus() {
			return bookStatus;
		}
		public void setBookStatus(String bookStatus) {
			this.bookStatus = bookStatus;
		}
		public String getShowName() {
			return showName;
		}
		public void setShowName(String showName) {
			this.showName = showName;
		}
		public String getLocation() {
			return location;
		}
		public void setLocation(String location) {
			this.location = location;
		}
		public String getDate() {
			return date;
		}
		public void setDate(String date) {
			this.date = date;
		}
		public float getPrice() {
			return price;
		}
		public void setPrice(float price) {
			this.price = price;
		}
		public int getAvailableSeats() {
			return availableSeats;
		}
		public void setAvailableSeats(int availableSeats) {
			this.availableSeats = availableSeats;
		}
		@Override
		public String toString() {
			return "BookTicket [showId=" + showId + ", showName=" + showName
					+ ", location=" + location + ", date=" + date + ", price="
					+ price + ", availableSeats=" + availableSeats
					+ ", bookStatus=" + bookStatus + ", custName=" + custName
					+ ", mobile=" + mobile + ", seats=" + seats + "]";
		}
		
		
		
		
		
		
	

}
