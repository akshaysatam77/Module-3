package com.capgemini.magicWorld.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.magicWorld.dto.BookTicket;
import com.capgemini.magicWorld.exception.BookException;
import com.capgemini.magicWorld.util.DbUtil;

public class ShowDaoImpl implements ShowDao {
    
	private DbUtil util;
	public ShowDaoImpl() {
		try {
			util=new DbUtil();
		} catch (BookException e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<BookTicket> showDetails() throws BookException {
		Connection connect=null;
		PreparedStatement pst=null;
		
		String query="SELECT SHOWID,SHOWNAME,LOCATION,SHOWDATE,PRICETICKET,AVSEATS FROM SHOWDETAILS";
		List<BookTicket> myList=new ArrayList<>();
		try{
			connect=util.obtainConnection();
			pst=connect.prepareStatement(query);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()){
				BookTicket book=new BookTicket();
				book.setShowId(rs.getString("SHOWID"));
				book.setShowName(rs.getString("SHOWNAME"));
				book.setLocation(rs.getString("LOCATION"));
				book.setDate(rs.getString("SHOWDATE"));
				book.setPrice(rs.getFloat("PRICETICKET"));
				book.setAvailableSeats(rs.getInt("AVSEATS"));
				myList.add(book);
				System.out.println(book);
			}
			return myList;
		}catch(SQLException e){
			//e.printStackTrace();
			throw new BookException("JDBC failed"+e);			
		}finally{
			try {
				if(pst!=null){
					pst.close();
				}
				if(connect!=null){
					connect.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}

	@Override
	public int updateSeats(String showName,int seats) throws BookException {
		Connection conn = null;
		PreparedStatement pstm = null;
		int value=0;
		//String query="UPDATE SHOWDETAILS SET AVSEATS=? WHERE SHOWNAME=?";
		try {
		conn=util.obtainConnection();
			pstm=conn.prepareStatement("UPDATE SHOWDETAILS SET AVSEATS=? WHERE SHOWNAME=?");
			pstm.setInt(1,seats);
			pstm.setString(2,showName);
			System.out.println(seats+"\n"+showName);
			
			value=pstm.executeUpdate();
			this.showDetails();
		System.out.println("Value in dao "+value);
		} catch (SQLException e) {
			
		throw new BookException("Problem in  data",e);
		}finally{
			
			try {
				if(pstm!=null)
				{
					pstm.close();
				}
				if(conn!=null)
				{
					conn.close();
				}
				
				
			} catch (SQLException e) {
			throw new BookException("Connection was not established",e);
			}
			
		}
	
		return value;
	}

	
	@Override
	public int checkAvailabeSeats(String showName) throws BookException {
		Connection connect=null;
		PreparedStatement pst=null;
		
		String query=null;
		
		query="SELECT AVSEATS FROM SHOWDETAILS WHERE SHOWNAME=?";
		
		int availableSeats=0;
		try {
			connect=util.obtainConnection(); 
			pst=connect.prepareStatement(query);
			pst.setString(1,showName);
		ResultSet res=pst.executeQuery();
		while(res.next()){
		availableSeats=res.getInt("AVSEATS");
		}
		}catch (SQLException e) {
			e.printStackTrace();
			//throw new BookException("Seat not available for "+showName);
		}finally{
			try {
				connect.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return availableSeats;
	}
	
	

}
