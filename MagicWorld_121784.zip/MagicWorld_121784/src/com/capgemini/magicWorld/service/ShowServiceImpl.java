package com.capgemini.magicWorld.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.magicWorld.dao.ShowDao;
import com.capgemini.magicWorld.dao.ShowDaoImpl;
import com.capgemini.magicWorld.dto.BookTicket;
import com.capgemini.magicWorld.exception.BookException;

public class ShowServiceImpl implements ShowService {

	private ShowDao dao;
	public ShowServiceImpl() {
		dao=new ShowDaoImpl();
	}

	@Override
	public List<BookTicket> showDetails() throws BookException {
		
		return dao.showDetails();
	}


	@Override
	public int updateSeats(String showName,int seats) throws BookException {
		
		return dao.updateSeats(showName,seats);
	}

	@Override
	public boolean isValidSeat(int seats,String showName) throws BookException {
		int availableSeats=dao.checkAvailabeSeats(showName);
		System.out.println(availableSeats);
		if(seats<=availableSeats && seats>0){
		return true;
		}
		return false;
	}
}
