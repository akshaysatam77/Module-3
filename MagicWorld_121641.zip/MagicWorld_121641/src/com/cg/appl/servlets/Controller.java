package com.cg.appl.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.appl.entities.BookTicket;
import com.cg.appl.exception.BookTicketException;
import com.cg.appl.service.showService;
import com.cg.appl.service.showServiceImpl;


@WebServlet("*.do")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	showService services;
	private RequestDispatcher dispatch;
	
	String message=null;
  
	public void init(ServletConfig config) throws ServletException {
		 services= new showServiceImpl();
	}

	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, BookTicketException {
		
		 String path = request.getServletPath();
		    System.out.println(path);
		    if(path.equals("/empl.do")){
			
				RequestDispatcher res = request.getRequestDispatcher("showdetails.jsp");
				res.forward(request, response);
		    }
		  if(path.equals("/showdetails.do")){
		
			List<BookTicket> myList;
			myList=services.showDetails();
			
			System.out.println(myList);
			request.setAttribute("data", myList);
			RequestDispatcher req=request.getRequestDispatcher("showdetails.jsp");
			req.forward(request, response);
			
			
		}
		  
		  else if(path.equals("/booknow.do")){
			  List<BookTicket> myList;
			  myList=services.showDetails();
			  request.setAttribute("data", myList);
			  
			  RequestDispatcher req=request.getRequestDispatcher("bookNow.jsp");
				req.forward(request, response);
			  
		  }
		  
		  else if(path.equals("/booknow.do")){
			  
			  String custname=request.getParameter("name");
			  Pattern name1=Pattern.compile("^[a-zA-z]$");
			  Matcher name=name1.matcher(custname);
			  request.setAttribute("cname", custname);
			  String mobnumber=request.getParameter("mnumber");
			  int number=Integer.parseInt(mobnumber);
			  Pattern number1=Pattern.compile("^[7|8|9]{1}[0-9]{9}$");
			  Matcher num=number1.matcher(mobnumber);
			  request.setAttribute("mno", mobnumber);
			  
			  String noseats=request.getParameter("nseats");
			  int seats = Integer.parseInt(noseats);
			  
			  request.setAttribute("aseats", noseats);
			 
			  
			
			  
			  if(name.matches() && num.matches()){
				  RequestDispatcher req=request.getRequestDispatcher("success.jsp");
					req.forward(request, response);
			  }else
			  {
				  message="Tickets are not booked.please enter valid credential";
				  request.setAttribute("errMsg", message);
				  RequestDispatcher req=request.getRequestDispatcher("error.jsp");
					req.forward(request, response);
			  }
			  
		  }
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request, response);
		} catch (BookTicketException e) {
			
		}	
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request, response);
		} catch (BookTicketException e) {
			
		}
	}

}
