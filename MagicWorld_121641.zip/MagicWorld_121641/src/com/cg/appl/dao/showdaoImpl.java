package com.cg.appl.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;




import com.cg.appl.entities.BookTicket;
import com.cg.appl.exception.BookTicketException;
import com.cg.appl.util.DbUtil;


public class showdaoImpl implements showDao {
	private DbUtil util;
	public showdaoImpl() {
		util=new DbUtil();
	}

	@Override
	public List<BookTicket> showDetails() throws BookTicketException {
		Connection connect = null;
		PreparedStatement pst = null;
		ResultSet res=null;
		String query="SELECT SHOWNAME,LOCATION,SHOWDATE,PRICE,,AVSEATS FROM SHOWDETAILS";
		List<BookTicket> myList = new ArrayList();
		try {
			connect=util.obtainConnection();
			pst=connect.prepareStatement(query);
			res=pst.executeQuery();
			while(res.next()){
				BookTicket bt= new BookTicket();
				bt.setShowName(res.getString("SHOWNAME"));
				bt.setLocation(res.getString("LOCATION"));
				bt.setDate(res.getString("SHOWDATE"));
				bt.setPrice(res.getFloat("PRICE"));
				bt.setAvailableSeats(res.getInt("AVSEATS"));
				myList.add(bt);
				System.out.println(myList);
			}
				
			return myList;
			
		} catch (BookTicketException | SQLException e) {
			
			e.printStackTrace();
			throw new BookTicketException("List Failed To Display",e);
		}finally{
			if(connect!=null)
			{
				try {
					connect.close();
				} catch (SQLException e) {
					throw new BookTicketException("JDBC Failed",e);
				}
			}
			if(pst!=null){
				try {
					pst.close();
				} catch (SQLException e) {
					throw new BookTicketException("JDBC Failed",e);
				}
			}
		}
		
	
	}

	@Override
	public boolean updateSeats(String showName, int seats)
			throws BookTicketException {
		Connection connect = null;
		PreparedStatement pst = null;
		String query="UPDATE SHOWDETAILS SET AVSEATS=? WHERE SHOWNAME=?" ;
		
		
		try {
			connect=util.obtainConnection();
			pst=connect.prepareStatement(query);
			pst.setInt(1, seats);
			pst.setString(2, showName);
			int rec= pst.executeUpdate();
			
			while(rec>0){
				return true;
				
			}
			
		} catch (SQLException e) {
			throw new BookTicketException("JDBC Failed",e);
		}finally{
			if(connect!=null)
			{
				try {
					connect.close();
				} catch (SQLException e) {
					throw new BookTicketException("JDBC Failed",e);
				}
			}
			if(pst!=null){
				try {
					pst.close();
				} catch (SQLException e) {
					throw new BookTicketException("JDBC Failed",e);
				}
			}
			
			
		}
		
		
		return false;
	}

}
