package com.cg.appl.dao;

import java.util.List;

import com.cg.appl.entities.BookTicket;
import com.cg.appl.exception.BookTicketException;

public interface showDao {

	List<BookTicket> showDetails() throws BookTicketException;
	boolean updateSeats(String showName,int seats) throws BookTicketException;
}
