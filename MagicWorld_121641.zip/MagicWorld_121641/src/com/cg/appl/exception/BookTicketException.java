package com.cg.appl.exception;

public class BookTicketException extends Exception {

	public BookTicketException() {
		
	}

	public BookTicketException(String arg0) {
		super(arg0);
		
	}

	public BookTicketException(Throwable arg0) {
		super(arg0);
		
	}

	public BookTicketException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		
	}

	public BookTicketException(String arg0, Throwable arg1, boolean arg2,
			boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		
	}

}
