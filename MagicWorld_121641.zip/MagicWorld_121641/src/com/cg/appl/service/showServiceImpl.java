package com.cg.appl.service;

import java.util.List;

import com.cg.appl.dao.showDao;
import com.cg.appl.dao.showdaoImpl;
import com.cg.appl.entities.BookTicket;
import com.cg.appl.exception.BookTicketException;

public class showServiceImpl implements showService {
	showDao dao;
	public showServiceImpl() {
		dao = new showdaoImpl();
	}

	@Override
	public List<BookTicket> showDetails() throws BookTicketException {
		
		return dao.showDetails();
	}

	@Override
	public boolean updateSeats(String showName, int seats)
			throws BookTicketException {
		
		return dao.updateSeats(showName, seats);
	}

}
