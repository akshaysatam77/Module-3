package com.cg.appl.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.appl.exception.BookTicketException;



public class DbUtil {
	
	public static Connection obtainConnection() throws BookTicketException{
		Connection conn=null;
		InitialContext context;
		
		try {
			context = new InitialContext();
			DataSource source = (DataSource)context.lookup("java:/OracleDS");
			conn = source.getConnection();
		} catch (NamingException e) {
			throw new BookTicketException("Problem In Connection");
			
		}catch(SQLException e){
			throw new BookTicketException("Problem In Connection");
		}
		return conn;
	}

}
