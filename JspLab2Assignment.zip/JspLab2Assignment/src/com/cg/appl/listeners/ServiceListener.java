package com.cg.appl.listeners;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.cg.appl.services.IUsermasterServices;
import com.cg.appl.services.UserMasterServicesImpl;

@WebListener
public class ServiceListener implements ServletContextListener {
 private IUsermasterServices services;
 ServletContext ctx=null;
   
	 public void contextInitialized(ServletContextEvent event)  { 
	      ctx=event.getServletContext();  
	      services=new UserMasterServicesImpl();
	      ctx.setAttribute("services", services);
	    }
	public void contextDestroyed(ServletContextEvent event)  { 
        
    }

   
	
}
