package com.cg.appl.services;

import java.util.List;

import com.cg.appl.entities.Bill;
import com.cg.appl.entities.Consumer;
import com.cg.appl.exceptions.UserException;

public interface IUsermasterServices {

	Consumer getUserDetails(String consumerNumber) throws UserException;
    int setUserDetails(Bill bill) throws UserException;
    public boolean isUserAuthenticated(String consumerNumber, String last, String current)throws UserException;
	public double calcUnits(double last,double current);
	public double calcAmount(double units);
	public List<Consumer>showAll() throws UserException;
	 List<Bill> getConsumerDetails(String consumerNumber) throws UserException;
}
