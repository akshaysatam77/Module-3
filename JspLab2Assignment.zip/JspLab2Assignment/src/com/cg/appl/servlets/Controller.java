package com.cg.appl.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.appl.entities.Bill;
import com.cg.appl.entities.Consumer;
import com.cg.appl.exceptions.UserException;
import com.cg.appl.services.IUsermasterServices;
import com.cg.appl.services.UserMasterServicesImpl;

@WebServlet("*.do")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    
	private RequestDispatcher dispatch;
	private String nextJsp;
	String message=null;
	 IUsermasterServices services;
	 Bill bill;
	 
	
	public void init(ServletConfig config) throws ServletException {
		services = new UserMasterServicesImpl();
		bill=new Bill();
	}
	
	private void ProcessRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	{
		String command=request.getServletPath();
		System.out.println(command);
		switch(command){
		
		case"/showall.do":{
			
			List<Consumer>myList;
			try {
				myList=services.showAll();
				request.setAttribute("data",myList);
				RequestDispatcher req=request.getRequestDispatcher("show.jsp");
				req.forward(request, response);
				
			} catch (UserException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;	
		}
		
		
		case"/search.do":{
			
			String uid = request.getParameter("id");
			System.out.println(uid);
			request.setAttribute("myid",uid);
			RequestDispatcher req=request.getRequestDispatcher("searchconsumer.jsp");
			req.forward(request, response);
		break;	
		}
		
		case "/showdetails.do":{
		String uid = request.getParameter("cNumber");
		System.out.println(uid);
		
		try {
			Consumer consume=services.getUserDetails(uid);
			System.out.println(consume);
			request.setAttribute("mydata",consume);
			RequestDispatcher req=request.getRequestDispatcher("consumerdetails.jsp");
			req.forward(request, response);
		} catch (UserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		break;
		
		}
		
		case "/consumerdetails.do":{
		   
			String uid = request.getParameter("id");
			request.setAttribute("num",uid);
			List<Bill> mybill = new ArrayList<>();
		 try {
			mybill=services.getConsumerDetails(uid);
			System.out.println(mybill);
			request.setAttribute("condetails",mybill);
			RequestDispatcher req=request.getRequestDispatcher("final.jsp");
			req.forward(request, response);
			
		} catch (UserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
		break;	
		}
		case "/showinfo.do":{
			RequestDispatcher req=request.getRequestDispatcher("billdetails.jsp");
			req.forward(request, response);
			
			break;
		}
		
		case"/index.do":
		{
			
			RequestDispatcher req=request.getRequestDispatcher("index.jsp");
			req.forward(request, response);	
			break;
		}
		
	
		
		case "/billDetails.do":{
			String consumerNumber=request.getParameter("number");
			String Last=request.getParameter("last");
			String Current=request.getParameter("current");
			double last=Double.parseDouble(Last);
			double current=Double.parseDouble(Current);
			boolean isAuth;
    		double netAmount;
    		double units;
    		Bill bill = null;
    		int update=0;
			try {
				isAuth=services.isUserAuthenticated(consumerNumber,Last,Current);
				if(isAuth)
				{
					bill=new Bill();
					Consumer consume=services.getUserDetails(consumerNumber);
					units=services.calcUnits(last, current);
					netAmount=services.calcAmount(units);
					bill.setConsumerNumber(consumerNumber);
					bill.setCurrReading(current);
					bill.setNetAmount(netAmount);
					bill.setUnitConsumed(units);
					update=services.setUserDetails(bill);
					request.setAttribute("name",consume.getName());
					request.setAttribute("number", consume.getNumber());
					request.setAttribute("units", units);
					request.setAttribute("netAmount", netAmount);
					nextJsp="/mainview.jsp";
					if(update==1){
						
						System.out.println("Database updated successfully");
						
					}else
					{
						System.out.println("failed to update database");
						
					}
					
				}
				
				else
				{
					message="Invalid Credentials.Please Enter Again";
					request.setAttribute("errormsg",message);
					nextJsp="/billdetails.jsp";
				}
				
				
			} catch (UserException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				message="Invalid Consumer Number";
				request.setAttribute("errormsg",message);
				nextJsp="/error.jsp";
			}
			break;	}
		
		}
		
		
		 dispatch=request.getRequestDispatcher(nextJsp);
		 dispatch.forward(request,response);
		}
		

		
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ProcessRequest(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ProcessRequest(request,response);
	}

}
