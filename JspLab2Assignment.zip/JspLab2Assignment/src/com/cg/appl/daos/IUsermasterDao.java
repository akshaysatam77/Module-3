package com.cg.appl.daos;

import java.util.List;

import com.cg.appl.entities.Bill;
import com.cg.appl.entities.Consumer;
import com.cg.appl.exceptions.UserException;


public interface IUsermasterDao {
	
	
	Consumer getUserDetails(String consumerNumber) throws UserException;
    int setUserDetails(Bill bill) throws UserException;
    public List<Consumer>showAll() throws UserException;
    List<Bill> getConsumerDetails(String consumerNumber) throws UserException;
}
