package com.cg.appl.entities;

import java.io.Serializable;
import java.sql.Date;

public class Bill implements Serializable{
private static final long serialVersionUID = 1L;

private int bill_num;
private String consumerNumber;
private double currReading;
private double unitConsumed;
private double netAmount;
private Date date;
public Bill() {
	super();
}
public Bill(String consumerNumber, double currReading, double unitConsumed,
		double netAmount, Date date) {
	super();
	this.consumerNumber = consumerNumber;
	this.currReading = currReading;
	this.unitConsumed = unitConsumed;
	this.netAmount = netAmount;
	this.date = date;
}


public int getBill_num() {
	return bill_num;
}
public void setBill_num(int bill_num) {
	this.bill_num = bill_num;
}
public String getConsumerNumber() {
	return consumerNumber;
}
public void setConsumerNumber(String consumerNumber) {
	this.consumerNumber = consumerNumber;
}
public double getCurrReading() {
	return currReading;
}
public void setCurrReading(double currReading) {
	this.currReading = currReading;
}
public double getUnitConsumed() {
	return unitConsumed;
}
public void setUnitConsumed(double unitConsumed) {
	this.unitConsumed = unitConsumed;
}
public double getNetAmount() {
	return netAmount;
}
public void setNetAmount(double netAmount) {
	this.netAmount = netAmount;
}
public Date getDate() {
	return date;
}
public void setDate(Date date) {
	this.date = date;
}
@Override
public String toString() {
	return "Bill [bill_num=" + bill_num + ", consumerNumber=" + consumerNumber
			+ ", currReading=" + currReading + ", unitConsumed=" + unitConsumed
			+ ", netAmount=" + netAmount + ", date=" + date + "]";
}




}
