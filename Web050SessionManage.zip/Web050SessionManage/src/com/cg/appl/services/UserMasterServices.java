package com.cg.appl.services;

import com.cg.appl.entities.User;
import com.cg.appl.exception.UserException;

public interface UserMasterServices {

	User getUserDetails(String userName) throws UserException;
	public boolean isUserAuthenticated(String userName, String password) throws UserException;
		
	
	
}
