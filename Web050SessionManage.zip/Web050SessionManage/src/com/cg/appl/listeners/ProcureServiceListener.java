package com.cg.appl.listeners;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.cg.appl.exception.UserException;
import com.cg.appl.services.UserMasterServices;
import com.cg.appl.services.UserMasterServicesImpl;


@WebListener
public class ProcureServiceListener implements ServletContextListener {
	private UserMasterServices services;
	private ServletContext ctx = null;
	
	
	public void contextInitialized(ServletContextEvent event)  { 
		
		ctx = event.getServletContext();
		
		try {
			services = new UserMasterServicesImpl();
			ctx.setAttribute("services", services);
		} catch (UserException e) {
			
			ctx.log(e.getMessage());
		
		}	
    }
 

    public void contextDestroyed(ServletContextEvent arg0)  { 
        
    }


   
	
}
