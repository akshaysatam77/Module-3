package com.cg.appl.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import oracle.jdbc.pool.OracleDataSource;

public class JdbcUtil {
		//private Properties props;
		private OracleDataSource dataSource;
		
		public JdbcUtil() {
			//props = new Properties();
			//InputStream is=null;
			
				//is = new FileInputStream("D:\\Servlet\\Web020LoginSimple\\src\\oracle.properties");
				//props.load(is);
				
				
					try {
						dataSource= new OracleDataSource();
					
				
				/*dataSource.setURL(props.getProperty("url"));
				dataSource.setUser(props.getProperty("user"));
				dataSource.setPassword(props.getProperty("password"));
				dataSource.setDriverType(props.getProperty("oracle"));
				*/
				
				dataSource.setURL("jdbc:oracle:thin:@10.125.6.62:1521:ORCL11G");
				dataSource.setUser("labg104trg11");
				dataSource.setPassword("labg104oracle");
				dataSource.setDriverType("oracle");
			
				
			//}// catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			//} //catch (IOException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			/*}*/ }catch(SQLException e){
				e.printStackTrace();
				
			}
			
		/*	finally{
				try {
					is.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}*/
			//}
			
		
		}
		public Connection getConnection() throws SQLException{
			return dataSource.getConnection();
		}
		@Override
		protected void finalize() throws Throwable {
			dataSource.close();
			super.finalize();
		}
		
		
		
}
