package com.cg.appl.servlets;

import java.io.IOException;



import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




import javax.servlet.http.HttpSession;

import com.cg.appl.entities.User;
import com.cg.appl.exception.UserException;
import com.cg.appl.services.UserMasterServices;
import com.cg.appl.services.UserMasterServicesImpl;

@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserMasterServices services;
	private RequestDispatcher dispatch;
	private String nextJsp;
	String message = null;
	ServletContext ctx = null;

	
	 
	public void init() throws ServletException {
		
		ctx = super.getServletContext();
		
		services =(UserMasterServices) ctx.getAttribute("services");
		
		
	}

		
	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String command = request.getServletPath();
		ctx.log("command" +command);
		
		switch(command){
		
		case "/login.do" :
			{
				nextJsp= "/login.jsp";
				break;		
			}
		
		case "/authenticate.do" :
			{
				String userName =request.getParameter("userNm");
				 String password=request.getParameter("password");
				
			
				 
				 try {
					boolean isAuthenticated=services.isUserAuthenticated(userName,password);
					 if(isAuthenticated){
					//start a session
						 User user = services.getUserDetails(userName);
						 HttpSession session = request.getSession(true);
						 ctx.log(session.getId());
						 session.setAttribute("user", user);
						 
						 nextJsp =  "/mainMenu.jsp";
						 
								
					 }else
					 
					 {
						// System.out.println("no");
						 message = "Wrong Credential. Enter again";
						 request.setAttribute("errorMsg", message);
						 nextJsp= "/login.jsp";
						
					 }
				} catch (UserException e) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
					
					message= "username does not exist.";
					request.setAttribute("errorMsg", message);
					ctx.log(e.getMessage());
					nextJsp = "/error.jsp";
					
					
				}
			
				break;
			}//End of case for authenticate.do
		
			
		case "/logout.do" : {
			HttpSession session = request.getSession(false);
			session.invalidate();   //destroys session
			nextJsp = "/login.jsp";
		}
			
		}
		
		dispatch = request.getRequestDispatcher(nextJsp);
		dispatch.forward(request, response);
	}
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		processRequest(request, response);
	}

	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		processRequest(request, response);
	}
	
	
	
	public void destroy() {
		services = null;

	}

}

